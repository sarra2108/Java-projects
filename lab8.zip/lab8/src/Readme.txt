Nom d'étudiant(e): Sarra Sassy
Numero d'étudiant: 123456
Code de cours: ITI1521
Section de lab: B02

Cette archive contient les 5 fichiers du laboratoire 8.

Spécifiquement, ce fichier (README.txt), ainsi que
Queue.java, ArrayQueue.java, Customer.java, Cashier.java.
