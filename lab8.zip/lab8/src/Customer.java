import java.util.Random;
public class Customer {
    private int arrival_time;
    private int numItems;
    private int nbnottreated_products;
    private final static int MAX_NUM_ITEMS=20;
    public Customer(int arrival_time) {
        this.arrival_time = arrival_time;


        Random generator;
        generator = new Random();

        int nItems;
        nItems = generator.nextInt(MAX_NUM_ITEMS-1)+1;
        this.numItems = nItems;
       int  n=nItems;

        this.nbnottreated_products=n;

    }
    public int getArrivalTime(){
        return arrival_time;
    }
    public int getNumberOfItems(){
        return nbnottreated_products;
    }
    public int getNumberOfServedItems(){
        return (numItems-nbnottreated_products);
    }
    public void serve(){

        nbnottreated_products--;
    }
}
