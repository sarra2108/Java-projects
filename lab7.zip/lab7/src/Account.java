public class Account {
    private double balance;
    NotEnoughMoneyException nem;

    public Account() {
        balance = 0.0;


    }

    public void deposit(double number) {
        balance = balance + number;
        System.out.println("new balance=" + balance + '$');
    }

    public void withdraw(double number) throws NotEnoughMoneyException {
        {
            if (number <= balance) {
                balance = balance - number;
                System.out.println("new balance=" + balance + '$');
            } else {
                nem = new NotEnoughMoneyException("ty n'as pas suffisament d'argent pour retirer" + number + "$", number, balance);
                throw nem;
            }
        }


    }
    public double getBalance(){
        return balance;}
}
