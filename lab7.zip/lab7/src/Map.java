
public interface Map< K, V> {

    /* Make the necessary abstract method definitions */
    public abstract V get(K key) throws  RuntimeException ;
    public abstract boolean contains(K key) throws RuntimeException ;
    public abstract void put(K key,V value)throws RuntimeException ;
    public abstract void replace(K key, V value)throws RuntimeException ;
    public V remove(K key) ;

}