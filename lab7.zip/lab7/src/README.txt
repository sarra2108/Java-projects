Nom de l'étudiante ou de l'étudiant: Sarra Sassi
Numéro d'étudiant: 300307853
Code du cours: ITI1521
Section de laboratoire: B02
Cette archive contient les 11 fichiers du laboratoire 6.

Spécifiquement, ce fichier (README.txt), ainsi que
Exercise1.java, Account.java, NotEnoughMoneyException.java, Stack.java, ArrayStack.java, DynamicArrayStack.java, FullStackException.java, Map.java, Dictionary.java, Pair.java.
