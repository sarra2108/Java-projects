import java.util.NoSuchElementException;

public class OrderedList implements OrderedStructure {

    // Implementation of the doubly linked nodes (nested-class)

    private static class Node {

        private Comparable value;
        private Node previous;
        private Node next;

        private Node(Comparable value, Node previous, Node next) {
            this.value = value;
            this.previous = previous;
            this.next = next;
        }
    }

    // Instance variables

    private Node head;

    // Representation of the empty list.

    public OrderedList() {
        // Your code here.
        head=new Node(null,head,head);

    }

    // Calculates the size of the list

    public int size() {
        // Remove line below and add your implementation.
        int c = 0;
        Node p;
        p = head.next;
        if (p == null) {
            return c;
        }
        while (p != head) {
            c++;
            p=p.next;

        }
        return c;
    }


    public Object get(int pos) {
        // Remove line below and add your implementation.
        if (pos>size() || pos<0){
            throw new IndexOutOfBoundsException();
        }

            Node p;
            p = head.next;

            for (int i=0; i<pos; i++) {
                p = p.next;

            }
            return p.value;


    }
    public boolean add( Comparable o ) {
        // Remove line below and add your implementation.
        boolean result=false;
        if(o==null){throw new NullPointerException(); }

        Node  p ;
        p = head;
        if(p.next==null){
           Node newNode = new Node (o, head,head);
           p.next=newNode;
           p.previous=newNode;
           return true;
        }
       p=p.next;

        while (p != head) {
            int comparison = p.value.compareTo(o);
            if (comparison == 0) {
                // new element is already in the list
                return false;
            } else if (comparison < 0) {
                // insert new node before current node
                p = p.next;
            } else {
                Node newnode = new Node(o, p.previous, p);
                p.previous.next = newnode;
                p.previous = newnode;
                p = p.next;
                result = true;
                return result;
            }
        }
           p=p.previous;
            Node newnode=new Node(o,p,p.next);
            p.next.previous=newnode;
            p.next=newnode;

            result=true;
            return result;

        }



    //Removes one item from the position pos.

    public void remove( int pos ) {
        // Remove line below and add your implementation.
        if (pos>size() || pos<0){
            throw new IndexOutOfBoundsException();
        }
        Node r;
        Node p;
        p = head.next;
        for (int i=0; i<(pos); i++) {
            p = p.next;
        }
        p.previous.next= p.next;
        p.next.previous = p.previous;

        int c=size();
        c--;
    }

    // Knowing that both lists store their elements in increasing
    // order, both lists can be traversed simultaneously.

    public void merge( OrderedList other ) {


int count=0;
while(count!=other.size()){
this.add((Comparable)other.get(count++));
}
    }



}
