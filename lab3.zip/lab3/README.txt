Nom d'etudiant(e): Sarra Sassi
Numero d'etudiant: 300307853
Code de cours: ITI1521
Section de lab: B02

Cette archive contient les 3 fichiers de lab 3, c'est-à-dire, ce fichier (README.txt),
puis les fichiers Utils.java et Rational.java.
