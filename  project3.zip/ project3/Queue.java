/***Vous n avez pas le droit de changer le contenu de cette classe***/
public interface Queue<E> {
    boolean isEmpty();
    void enqueue(E o);
    E dequeue();
}
