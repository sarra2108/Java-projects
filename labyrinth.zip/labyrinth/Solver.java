public class Solver {

    public static String solve(Labyrinth labyrinth) {

	Queue<String> q = new LinkedQueue<String>();

	String newpath = "";

	q.enqueue(newpath);

	boolean solved = false;

	while (!solved && !q.isEmpty()) {

	    String path = q.dequeue();

	    for (int m=0; m < Labyrinth.MOVES.length && !solved; m++) {

		newpath = path + Labyrinth.MOVES[m];

		if (labyrinth.checkPath(newpath)) {
		    if (labyrinth.reachesGoal(newpath)) {
			solved = true;
		    } else {
			q.enqueue(newpath);
		    }
		}
	    }
	}

	if (! solved) {
	    newpath = null;
	}
	
	return newpath;
    }

}
