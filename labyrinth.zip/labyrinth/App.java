import java.awt.*;
import java.awt.event.*;

import java.io.IOException;

public class App extends Frame {

    // constants

    private static final int INIT_ROW = 10;
    private static final int INIT_COL = 15;

    // model

    private Labyrinth model;

    // view

    private TextArea output;
    private TextArea console;

    private Button bClear;
    private Button bSolve;

    private static String newline = System.getProperty("line.separator");
    
    public App() {

	super("Labyrinth");

	addWindowListener(new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
		    quit();
		}
	    });

	setLayout(new BorderLayout());

	output = new TextArea("", INIT_ROW, INIT_COL, TextArea.SCROLLBARS_NONE);

	output.setFont(new Font("Monospaced", Font.BOLD, 18));
	output.setBackground(Color.white);

	add(output, BorderLayout.CENTER);

	//  ------------------------------------------------------

	Panel buttons = new Panel(new GridLayout(1,2));

	//  ------------------------------------------------------

	bClear = new Button("Clear");

	bClear.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    clear();
		}
	    });

	buttons.add(bClear);

	//  ------------------------------------------------------

	bSolve = new Button("Solve");
	bSolve.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    solve();
		}
	    });

	buttons.add(bSolve);

	//  ------------------------------------------------------

	console = new TextArea("paste-in a maze and press solve" + newline, 5, 60);

	console.setEditable(false);
	console.setBackground(Color.white);
	console.setForeground(Color.gray);

	//  ------------------------------------------------------

	Panel control = new Panel(new BorderLayout());
	control.add(buttons, BorderLayout.NORTH);
	control.add(console, BorderLayout.CENTER);

	//  ------------------------------------------------------

	add(control, BorderLayout.SOUTH);

	pack();
	setVisible (true);
    }

    private void clear()  {
	output.setText("");
	console.append("paste-in a maze and press solve" + newline);
    }

    private void solve() {

	try {
	    model = Labyrinth.readString(output.getText());

	    String path = Solver.solve(model);

	    if (path == null) {
		console.append("this maze has no solution" + newline);
	    } else {
		model.trace(path);
		output.setText(model.toString());
		console.append("solution = " + path + newline);
	    }

	} catch (IOException e) {
	    console.append(e.getMessage() + newline);
	} catch (IllegalArgumentException e) {
	    console.append(e.getMessage() + newline);
	}

    }

    private void quit() {
	System.exit (0);
    }

    public static void main(String[] args) {
	new App();
    }
}
