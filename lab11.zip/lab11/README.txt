Student name: Sarra Sassi
Student number: 300307853
Course code: ITI 1521
Lab section: B

Cette archive contient les 4 fichiers du laboratoire 11.

Spécifiquement, ce fichier (README.txt), ainsi que
Iterator.java, BitList.java, Iterative.java.
