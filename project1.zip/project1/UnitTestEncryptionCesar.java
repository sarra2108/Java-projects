import org.junit.jupiter.api.Test;


import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;


public class UnitTestEncryptionCesar {
    @Test
    public void testEncryption() {
        Random random = new Random();
        EncryptionCesar ceaser = new EncryptionCesar(3);
        for (int i = 0; i < 10; i++) {
            String plaintext = generateRandomString(random);
            String ciphertext = ceaser.Encrypter(plaintext);
            String decrypted = ceaser.Decrypter(ciphertext);
            assertEquals(plaintext, decrypted);
        }
    }

    private String generateRandomString(Random random) {
        int length = random.nextInt(10) + 1;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append((char)('a' + random.nextInt(26)));
        }
        return sb.toString();
    }
}
