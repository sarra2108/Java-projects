import java.util.*;

public class EncryptionCesar {
    //
    //TODO - Ajouter votre code (variable d instance etc) ici
    int decalage;
    String message;

    //
    //TODO - Ajouter votre constructeur ici
    public EncryptionCesar(int decalage){
        this.decalage=decalage;
        this.message=message;
    }

    //
    // Encrypte le message envoy� en param�tre et retourne le message encrypt�
    //
    public String Encrypter (String message) {
        //
        //TODO - Ajouter votre code ici
        char[] ch = message.toCharArray();
        for (int i = 0; i < message.length(); i++) {
            ch = message.toCharArray();

            ch[i] =(char) ((ch[i]-'a'+decalage)%26 + 'a');

        }
        String str=new String(ch);
        return str;
    }

    //
    // decrypte le message envoy� en param�tre et retourne le message original
    //
    public String Decrypter (String message) {
        //
        //TODO - Ajouter votre code ici
        char[] ch=message.toCharArray();
        for (int i = 0; i < message.length(); i++) {
             ch = message.toCharArray();
            ch[i] = (char) ((ch[i] -decalage-'a'+26)%26 +'a') ;


        }

        String str=new String(ch);
        return str;
    }



    public static void main (String[] args) {
        if (args.length !=2) {
            System.out.print("Utilisation: java EncryptionCesar <Message:string> <Decalage:int>");
            return;
        }

        String messageAvantEncryption = args[0];
        int decalage = Integer.parseInt(args[1]);

        EncryptionCesar encryption = new EncryptionCesar(decalage);

        System.out.println ("Message avant Encryption: " + messageAvantEncryption);
        String messageEncrypter = encryption.Encrypter(messageAvantEncryption);
        System.out.println ("Message apres Encryption: " + messageEncrypter +  " (decalage="+ decalage + ")");
        String messageApresDecryption= encryption.Decrypter(messageEncrypter);
        System.out.println ("Message apres Decryption: " + messageApresDecryption);
    }
}