public class MatriceIrreguliere {
    private double[] tableauParam;
    //
    //TODO - Ajouter votre code ici
    private int M;
    private int N;
    private int nombreElement;
    private int tailleColonne;


    public MatriceIrreguliere(double[] tableauParam, int nombreElements, int tailleColonne) {
        //
        //TODO - Ajouter votre code ici
        this.tableauParam = tableauParam;
        this.nombreElement = nombreElements;
        this.tailleColonne = tailleColonne;
    }

    //
    //TODO - Vous pouvez aussi ajouter autant de methode de classe ou d'instance, de constructeur,  private ou public, selon votre guise.

    public String toString() {
        //
        //TODO - Ajouter votre code ici
        double max = tableauParam[0];
        for (int i = 0; i < nombreElement; i++) {
            if (tableauParam[i] > max) {
                max = tableauParam[i];
            }
        }
        StringBuffer ch = new StringBuffer();
        String maxCh = max + "";
        int cell = maxCh.length();
        int nbDash = cell * tailleColonne;
        int N = getN();
        String ch1="";
        for (int k=0;k<nbDash;k++){
            ch1= ch1+"-";
        }
        
        for (int j = 0;j < getM();j++) {
            ch.append(ch1);
            ch.append("\n");

            for (int i = 0; i < getN(); i++) {
                if(tableauParam[j*getN()+i]!=0) {
                    ch.append(tableauParam[j * getN() + i]).append("|");
                }
            }

            ch.append("\n");
        }
        ch.append(ch1);



        return ch.toString();
    }

    public Double getMin(int ligne) {
        //TODO - Ajouter votre code ici
        int j;
        double min;
        if (ligne == 0) {
            j = 0;
        } else {
            j = ligne * tailleColonne;
        }
        min = tableauParam[0];
        for (int i = j; i < j + tailleColonne; i++) {
            if (min > tableauParam[i]&&tableauParam[i]!=0) {
                min = tableauParam[i];
            }
        }
        return min;
    }

    public Double getMax(int ligne) {
        //
        //TODO - Ajouter votre code ici
        int j;
        double max;
        if (ligne == 0) {
            j = 0;
        } else {
            j = ligne * tailleColonne;
        }
        max = tableauParam[0];
        for (int i = j; i < j + tailleColonne; i++) {
            if (max < tableauParam[i]) {
                max = tableauParam[i];
            }
        }
        return max;
    }


    public int getM() {
        //
        //TODO - Ajouter votre code ici

        if (nombreElement%tailleColonne==0){
            M=nombreElement/tailleColonne;
        }
        else{
            M=nombreElement/tailleColonne+1;
        }
        return M;
    }

    public int getN() {
        //
        //TODO - Ajouter votre code ici
        N= tailleColonne;
        return N;
    }

    public Double getMin() {
        double m = tableauParam[0];
        //TODO - Ajouter votre code ici
        for (int i = 0; i < tableauParam.length; i++) {
            if (m >= tableauParam[i] &&tableauParam[i]!=0) {
                m = tableauParam[i];
            }
        }
        return m;
    }

    public Double getMax() {
        //
        //TODO - Ajouter votre code ici
        double M = tableauParam[0];
        //TODO - Ajouter votre code ici
        for (int i = 0; i < tableauParam.length; i++) {
            if (M <= tableauParam[i]&& tableauParam[i]!=0) {
                M = tableauParam[i];
            }
        }
        return M;
    }

    public Double getTotal() {
        //
        //TODO - Ajouter votre code ici
        double s = 0;
        for (int j = 0; j < nombreElement; j++) {
            s = s + tableauParam[j];

        }
        return s;
    }


}
