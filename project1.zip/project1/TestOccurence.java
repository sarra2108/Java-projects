import java.util.*;
import java.io.*;
import java.util.regex.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class TestOccurence {
  public static final int TAILLEALPHABET = 26;


  public static void main(String[] args) throws Exception {
    if (args.length != 2) {
      System.out.print("Utilisation: java TestOccurence <fichier:string> <fichier:string>");
      return;
    }
    String fichierinput = args[0];
    String fichierOutput = args[1];

    Occurence[] occurences = new Occurence[TAILLEALPHABET * 2];

    //
    //TODO - Ajouter votre code ici pour initaliser votre tableau
    for (int i = 0; i < TAILLEALPHABET; i++) {
      int a=0;
      a =  ('a' + i);

      occurences[i] = new Occurence(String.valueOf((char) a));
    }
    for (int i = TAILLEALPHABET; i < TAILLEALPHABET * 2; i++) {
      int b=0;
      b=('A' + i - 26);
      occurences[i] = new Occurence(String.valueOf((char) b ));
    }

    FileReader fileReader = new FileReader(fichierinput);


    //
    // Lire le fichier, pour chaque caractere incrementer son comptage.
    //TODO - Ajouter votre code ici
    String fileName = "Input.txt";

    BufferedReader br = new BufferedReader(new FileReader(fichierinput));
    try {

      int line;
      while ((line = br.read()) != -1) {
        char ch = (char) line;
        for (int i = 0; i < 52; i++) {
          String a = Character.toString((ch));
          if (occurences[i].getMot().equals(a)) {
            occurences[i].incrementation();
          }
        }
      }
    } finally {
      br.close();
    }


    //Vous pouvez utiliser le code commente ci-dessous pour tester le contenu
    //de votre tableau d'occurences.
    //for (int i=0 ; i<occurences.length ; i++) {
    //    System.out.println(occurences[i].toString());
    //}


    //Naviguez votre tableau d occurence et ecrivez les statistiques selon le format demande.
    //TODO: Metter votre code ici
    try {
      FileWriter output = new FileWriter(fichierOutput);
      for (int i = 0; i < 52; i++) {
        if (occurences[i].getRepetition() > 0) {
          output.write(occurences[i].toString() + "\n");

        }
      }

      output.close();
    } catch (Exception e) {
      System.out.println(e);
    }


  }
}

