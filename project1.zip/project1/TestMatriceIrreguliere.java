import java.util.Scanner;
public class TestMatriceIrreguliere {
    public static void main (String[] args) {if (args.length !=2) {
        System.out.print("Utilisation: <java> <MatriceIrreguliere>  <MaxM:int> <n:int>");
        return;}

        Scanner sc= new Scanner(System.in);
        int M= Integer.parseInt(args[0]);
        int N=Integer.parseInt(args[1]);
        int nombreElement=M*N;
        double[]tableauParam= new double[nombreElement];
        int j=0;

        System.out.println("Entrez des nombres 1 par 1. Entrez 0 pour terminer.");
    //TODO - Ajouter votre code ici pour ramasser les entrees de l utilisateur
    //       et mettre les donnees dans un tableau temporaire
    while (true){
        tableauParam[j]=sc.nextDouble();
        if (tableauParam[j]==0){
            break;
        }
        else{ j++;}
    }
    nombreElement= j-1;
    for (int i=0;i<j+1;i++){
        tableauParam[i]= Math.round(tableauParam[i] * 10) / 10.0;
    }


    MatriceIrreguliere matrice = new MatriceIrreguliere(tableauParam,nombreElement,N);
    System.out.println("Matrice/Affichage");
    System.out.println(matrice.toString());
    System.out.println();

    int nombreLignes =matrice.getM();
    System.out.println("Nombre de lignes=" + nombreLignes);
    for (int i=0; i<nombreLignes ; i++) {
        System.out.println("Ligne #" + i + "/ Min=" + matrice.getMin(i) + ", Max="+ matrice.getMax(i));
    }
    System.out.println("Matrice/ Min=" + matrice.getMin() + ",Max="+matrice.getMax());
    System.out.println("Matrice/ Total=" + matrice.getTotal());
}
}
