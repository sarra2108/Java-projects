import java.util.*;

/**
 * la classe EncryptionCesar qui implemente l algorithme d encryption selon la methode de Cesar
 *
 * @author Livaniaina Rakotomalala (lrakotom@uottawa.ca)
 * @version 02/11/2023
 */
public class EncryptionCesar extends SubstitutionEncryption {
    private int decalage;

    /**
     * construit un object EncryptionCesar
     * @param decalage le nombre decalage des caracters
     * e.g. decalage = 2 alors Encrypter('a') = 'c', Encrypter('y') = 'a', Encrypter('A')= 'C', Encrypter('Y') = 'A'
     */
    public EncryptionCesar (int decalage) {
        super();
        this.decalage = decalage;
        tableauSubstitutions = new char[2][52];

        for (int i = 0; i < Util.ALPHABET.length(); i++) {
            char c = Util.ALPHABET.charAt(i);
            if (Character.isUpperCase(c)) {
                char ch = (char) (((int) c + decalage - 65) % 26 + 65);
                tableauSubstitutions[0][i] = c;
                tableauSubstitutions[1][i] = ch;
            } else {
                char ch = (char) (((int) c + decalage - 97) % 26 + 97);
                tableauSubstitutions[0][i] = c;
                tableauSubstitutions[1][i] = ch;
            }
        }
    }



        /**
         * Encrypte le message envoyé en paramètre et retourne le message encrypté
         * @param message le message a encrypter
         * @return le message encrypte
         */
    public String Encrypter (String message) {
        return super.Encrypter(message);
    }

    /**
     * decrypte le message envoyé en paramètre et retourne le message original
     * @param message le message a decrypter
     * @return le message decrypter
     */
    public String Decrypter (String message) {
        return super.Decrypter(message);
    }

    /**
     * Methode principale d acces pour l execution
     * @param args les arguments de la ligne de commande
     */
    public static void main (String[] args) {
        if (args.length !=2) {
            System.out.print("Utilisation: java EncryptionCesar <Message:string> <Decalage:int>");
            return;
        }

        String messageAvantEncryption = args[0];
        int decalage = Integer.parseInt(args[1]);

        EncryptionCesar encryption = new EncryptionCesar(decalage);

        System.out.println ("Message avant Encryption: " + messageAvantEncryption);
        String messageEncrypter = encryption.Encrypter(messageAvantEncryption);
        System.out.println ("Message apres Encryption: " + messageEncrypter +  " (decalage="+ decalage + ")");
        String messageApresDecryption= encryption.Decrypter(messageEncrypter);
        System.out.println ("Message apres Decryption: " + messageApresDecryption);
    }
}
