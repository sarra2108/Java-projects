
Nom de l'étudiante : Sarra Sassi_Ranim Raddedi
Numéro d'étudiant: 300307853_300323913
Code du cours: ITI1521


Cette archive contient les 23 fichiers du devoir.

Spécifiquement, ce fichier (README.txt), ainsi que
•Transactions.csv 
• Encryption.java
• SubstitutionEncryption.java
• EncryptionCesar.java
• UnitTestEncryption.java
• Occurence.java
• OccurenceCollection.java
• ProduitsEtServices.java
• Identifiable.java
• Produit.java
• Service.java
• Carte.java
• Poster.java
• Jersey.java
• JournalTransactions.java
• TestUtils.java
• Util.java
• StudentInfo.java
• hamcrest‐core‐1.3.jar
• junit‐4.13.jar