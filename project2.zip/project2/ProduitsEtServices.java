/**
 * La classe abstraite ProduitsEtServices qui definit uniquement un taxRate par defaut des champs abstraites que
 * chaque sous classe doit concretement definir
 * @author Livaniaina Rakotomalala (lrakotom@uottawa.ca)
 * @version 02/12/2023
 *
 *  * NOTE: ***Vous n avez pas le droit de changer le contenu de cette classe***
 */
public abstract class ProduitsEtServices {
    protected Double taxRate = 0.13;

    abstract String getName();
    abstract void setName(String name);
    abstract Double getPrice();
    abstract void setPrice(Double price);
 
    /**
     * constructeur par defaut
     */
    protected ProduitsEtServices () {
        ;
    }

    /**
     * Constructeur qui permet de faire un overwrite du tax rate
     * @param taxRate
     */
    protected ProduitsEtServices (Double taxRate) {
        this.taxRate = taxRate;
    }
}