/**
 * La classe abstraite Jersey 
 * @author Livaniaina Rakotomalala (lrakotom@uottawa.ca)
 * @version 02/12/2023
 *
 */
public class Jersey extends Produit {
    private Boolean isCustomized = false;

    public Jersey(String name, String sku, Double unitPrice, Double taxRate) {
        super (name, sku, unitPrice, taxRate);
    }

    /**
     * verifie si le jersey a ete personnalise
     * @return vrai si le jersey a ete personnalise
     */
    public Boolean getIsCustomized() {
        return this.isCustomized;
    }

    //Il manque exactement trois methodes a cette classe. Elle ne compilera pas tant que vous ne les ajoutiez pas
    //Inspirez vous des deux autres classes (Poster et Carte) pour la remplir. 
    //
    //TODO: Ajouter votre code ici.
    public void setIsCustomized(boolean isCustomized){
        this.isCustomized=isCustomized;

    }
    public Produit.ProductType getProductType() {
        return ProductType.JERSEY;
    }
}