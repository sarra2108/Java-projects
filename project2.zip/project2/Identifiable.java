/**
 * L interface Identifiable qui permet d identifier une classe qui l implemente
 * @author Livaniaina Rakotomalala (lrakotom@uottawa.ca)
 * @version 02/12/2023
 *
 */
public interface Identifiable{
    String getId();
}