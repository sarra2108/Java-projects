//NOTE: ***Vous n avez pas le droit de changer le contenu de cette classe***
public interface Stack<E> {
    boolean isEmpty();
    E peek();
    E pop();
    void push( E element);
}
