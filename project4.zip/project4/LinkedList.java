import java.util.*;

public class LinkedList<E> implements List<E> {

    private static class Node<T> {
      private T value;
      private Node<T> prev;
      private Node<T> next;


      private Node(T value, Node<T> prev, Node<T> next) {
        this.value = value;
        this.prev = prev;
        this.next = next;
      }
    }
    
    private Node<E> head;
    private int size;

    
    public LinkedList() {
        head = new Node<E>(null, null, null);
        head.prev = head;
        head.next = head;
        size = 0;

    }

    public int size() {
      return size;
    }
 
    public E get(int pos) {
 
      if (pos < 0 || pos >= size) {
        throw new IndexOutOfBoundsException(Integer.toString(pos));
      }
      
      Node<E> p;
      p = head.next;
      
      while (pos > 0) {
        p = p.next;
        pos--;
      }

      return p.value;
    }

    public void add(E element, int pos) {

      if (element == null) {
        throw new NullPointerException();
      }
      
      if (pos < 0 || pos > size) {
        throw new IndexOutOfBoundsException(Integer.toString(pos));
      }
      
      Node<E> before, after;
      before = head;
      
      while (pos > 0) {
        before = before.next;
        pos--;
      }

      after = before.next;
      
      before.next = new Node<E>(element, before, after);
      after.prev = before.next;
      
      size++;
    }

    public void remove(int pos) {

      if (pos < 0 || pos >= size) {
        throw new IndexOutOfBoundsException(Integer.toString(pos));
      }
      
      Node<E> before, after;
      before = head;
      
      while (pos > 0) {
        before = before.next;
        pos--;
      }
      
      after = before.next.next;
      
      before.next = after;
      after.prev = before;
      
      size--;
    }

    public boolean remove(E element) {
 
      if (element == null) {
        throw new NullPointerException();
      }
      
      Node<E> p, before, after;
      p = head.next;
      
      while (p != head && ! p.value.equals(element)) {
        p = p.next;
      }
      
      if (p == head) {
        return false;
      }
      
      before = p.prev;
      after = p.next;
      
      before.next = after;
      after.prev = before;
      
      size--;
      
      return true;
    }

    public LinkedList<E> splitAfter (E obj) {
        //TODO: Ajouter votre code ici.
        //vous n avez pas le droit d appeler les methodes d instances de cette classe sauf le constructeur..
        LinkedList<E> nouvellelist = new LinkedList<E>();
        Node<E> p = head.next;
        int i = 0;

        while (p != head) {
            if (p.value.equals(obj)) {
                nouvellelist.head.next =p.next;
               head.prev.next = nouvellelist.head;
                p.next = head;
                head.prev =p;
                nouvellelist.size = size - (i + 1);
                size = i + 1;

                return nouvellelist;
            }
            p =p.next;
            i++;
        }
        throw new IllegalArgumentException("Element not found");
    }

    //TODO: Ajouter votre code ici pour l iterateur 
    public Iterator<E> iterator() {
        return new LinkedListIterator();
    }
    public class LinkedListIterator implements Iterator<E> {
        private Node<E> current;


        public boolean hasNext() {
            if (current == null && head != null) {
                return true;
            } else if (current != null && current.next != null) {
                return true;
            } else {
                return false;
            }
        }
        public boolean hasPrev() {

                if (current == null && head != null) {
                    return true;
                } else if (current != null && current.prev != head) {
                    return true;
                } else {
                    return false;
                }

        }

        public E next() {

            if (current == null) {
                current = head;
            } else {

                    current = current.next;
                    }

            if (current == head) {
                current = current.next;
            }

            return current.value;
        }

        public E prev() {
            if (current == null) {
                current = head;
            } else {

                current = current.prev;
            }

            if (current == head) {
                current = current.prev;
            }



            return current.value;
        }
    }
        



    public String toString() {

      StringBuffer b;
      b = new StringBuffer("LinkedList [");
      
      Node<E> p;
      p = head.next;
      
      while (p != head) {
        b.append(p.value);
        if (p.next != head) {
          b.append(",");
        }
        p = p.next;
      }
      
      b.append("]");
      
      return b.toString();
    }
    
    
}
