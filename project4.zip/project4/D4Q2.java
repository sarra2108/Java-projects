public class D4Q2 {

    public static void main(String[] args) {


		LinkedList<Integer>l = new LinkedList<Integer>();
		LinkedList<Integer> l2;
		l2 = new LinkedList<Integer>();
		System.out.println(l);
		System.out.println(l.size());

		for (int i=0; i<5; i++) {
			l.add(i, 0);
			System.out.println(l);
			System.out.println(l.size());

		}
		l2 = l.splitAfter(2);
		System.out.println("c'est l'ancienne liste "+l);
		System.out.println(l.size());
		System.out.println("c'est la nouvelleliste "+l2);
		System.out.println(l2.size());

		for (int i=0; i<5; i++) {
			l.add(i+5, i);
			System.out.println(l);
			System.out.println(l.size());
		}

		l.add(11, l.size());
		System.out.println(l);
		System.out.println(l.size());
		
		for (int i=0; i<5; i++) {
			l.remove(i);
			System.out.println(l);
			System.out.println(l.size());
		}
		l2 = l.splitAfter(8);
		System.out.println("c'est l'ancienne liste "+ l);
		System.out.println(l.size());
		System.out.println("c'est la nouvelleliste "+l2);
		System.out.println(l2.size());

		l.remove(l.size()-1);
		System.out.println(l);
		System.out.println(l.size());

		l.remove(Integer.valueOf(6));
		l.remove(Integer.valueOf(6));
		System.out.println(l);
		System.out.println(l.size());

		l.remove(Integer.valueOf(0));
		l2 = l.splitAfter(2);
		System.out.println("c'est la nouvelleliste "+l2);
		System.out.println(l);
		System.out.println(l.size());

		l.remove(Integer.valueOf(4));
		System.out.println(l);
		System.out.println(l.size());

		l.remove(Integer.valueOf(8));
		System.out.println(l);
		System.out.println(l.size());

		l.remove(Integer.valueOf(2));
		System.out.println(l);
		System.out.println(l.size());

    }    
}
