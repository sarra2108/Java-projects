public class D4Q1 {

    public static void main(String[] args) {

        CircularArrayQueue<String> q1 = new CircularArrayQueue<String>(10);
        q1.enqueue("A");
        q1.enqueue("B");
        q1.enqueue("C");
        q1.enqueue("D");
        q1.enqueue("E");
        q1.enqueue("F");
        System.out.println(q1);
       q1.rotate(3);
        System.out.println(q1);

        CircularLinkedQueue<String> q2 = new CircularLinkedQueue<String>();
        q2.enqueue("A");
        q2.enqueue("B");
        q2.enqueue("C");
        q2.enqueue("D");
        q2.enqueue("E");
        q2.enqueue("F");
        System.out.println(q2);
        q2.rotate(58);
        System.out.println(q2);

        Queue<String> q3 = new CircularArrayQueue<String>(5);
        System.out.println(q3.toString());
        try {
            q3.dequeue();
        }
        catch (RuntimeException e) {
            System.out.println(e.getMessage());
        }

        try {
            q3.enqueue("E");
            q3.enqueue("F");
            q3.enqueue("G");
            q3.enqueue("H");
            q3.enqueue("I");
            q3.enqueue("J");
        }
        catch (RuntimeException e) {
            System.out.println(q3.toString());
            System.out.println(e.getMessage());
        }
    }
}
