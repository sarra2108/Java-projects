Nom de l'étudiante ou de l'étudiant: Sarra Sassi
Numéro d'étudiant: 300307853
Code du cours: ITI1521
Section de laboratoire: B02
Cette archive contient les 7 fichiers du laboratoire 6.

Spécifiquement, ce fichier (README.txt), ainsi que
ArrayStack.java, Dictionary.java, DynamicArrayStack.java, Pair.java, Map.java, Stack.java.
