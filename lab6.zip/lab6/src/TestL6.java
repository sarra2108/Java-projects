public class TestL6 {

   public static void main(String[] args) {
    TestUtils.runClass(TestL6ArrayStack.class);
    TestUtils.runClass(TestL6DynamicArrayStack.class);

    TestUtils.runClass(TestL6Dictionary.class);
  }

}
