public class Book {

    // Your variables declaration here
    private String author;
    private String title;
    private int year;

    public Book (String author, String title, int year) {
        // Your code here
        this.author=author;
        this.title=title;
        this.year=year;
    }

    public String getAuthor() {
        // Your code here
        return author;
    }

    public String getTitle() {
        // Your code here
        return title;
    }

    public int getYear() {
        // Your code here
        return year;
    }

    public boolean equals(Object other) {
        // Your code here
        if(this==other) return true;
        if ((other instanceof Book)==false) return false;
        Book book = (Book) other;
        if(this.getAuthor()==null && book.getAuthor()!=null || this.getAuthor()!=null && book.getAuthor()==null){
            return false;
        }
        if(this.getTitle()==null && book.getTitle()!=null || this.getTitle()!=null && book.getTitle()==null){
            return false;
        }

        if ((this.getAuthor()==null && book.getAuthor()!=null )){
            return this.getTitle().equals(book.getTitle())&&this.getYear()==book.getYear();
        }
        if ((this.getTitle()==null && book.getTitle()!=null )){
            return this.getAuthor().equals(book.getAuthor())&&this.getYear()==book.getYear();
        }
        if(this.getAuthor()==null && book.getAuthor()==null) {
            return this.getTitle().equals(book.getTitle())&&this.getYear()==book.getYear();
        }

        if(this.getTitle()==null && book.getTitle()==null ){
            return this.getAuthor().equals(book.getAuthor())&&this.getYear()==book.getYear();
        }
        int x = this.getAuthor().compareTo(book.getAuthor());
        if (x == 0) {
            x = this.getTitle().compareTo(book.getTitle());
            if (x == 0) {
                x = Integer.compare(this.getYear(), book.getYear());
            }
        }

        return x==0;

    }


    public String toString() {
        // Your code here
        return author+":"+title+"("+year+")";
    }
}
