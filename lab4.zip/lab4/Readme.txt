Nom d'étudiant(e): Sarra Sassy
Numero d'étudiant: 123456
Code de cours: ITI1521
Section de lab: B02

Cette archive contient les 6 fichiers de lab 4, c'est-à-dire, ce fichier (README.txt),
puis les fichiers Likeable.java, Post.java, TextPost.java, PhotoPost.java, NewsFeed.java.