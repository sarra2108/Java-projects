import java.util.Scanner;
import java.util.Stack;

/**
 * la classe utilitaire ZeroEtNeuf 
 * @author Livaniaina Rakotomalala (lrakotom@uottawa.ca)
 * @version 03/17/2023
 */
public class ZeroEtNeuf {
    
    /**
     * resoud le probleme qui cherche le plus petit nombre positif multiple de n et qui contient juste des zeros et des neufs
     * @param n
     * @return le chiffre compose juste de zeros et de neufs.
     */
    public int resoudre(int n) {
        int resultat = 0;
        Queue<String> q;
        q = new LinkedQueue<String>();

        // TODO: Insert votre code ici




        q.enqueue("9");
        String s;
        while (true) {

            s = q.dequeue();

            resultat=Integer.parseInt(s);
            if (resultat%n==0){
                break;
            }
            q.enqueue(s + "0");
            q.enqueue(s + "9");
        }


        return resultat;

        }

    public static void main(String[] args) {
        if (args.length !=1) {
            System.out.print("Utilisation: java ZeroEtNeuf <n:int>");
            return;
          } 

        int n = Integer.parseInt(args[0]);
        ZeroEtNeuf zeroEtNeuf = new ZeroEtNeuf();
        System.out.println("Le plus petit nombre multiple de " + n + " compose juste de [0,9] est:  " + zeroEtNeuf.resoudre(n));
    }
}