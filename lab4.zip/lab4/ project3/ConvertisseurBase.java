import java.util.Stack;

/**
 * la classe ConvertisseurBase qui convertit un nombre en base 10 vers un autre nombre de base quelconque
 * @author Livaniaina Rakotomalala (lrakotom@uottawa.ca)
 * @version 03/17/2023
 */
public class ConvertisseurBase {
    
    /**
     * 
     * @param n le nombre
     * @param b la base (Hypothese:  b>1)
     * @return la version du nombre @param n en base @param b
     */
    public int convert(int n, int b) {
        LinkedStack<Integer> s;
        s = new LinkedStack<Integer>();

        // TODO: Insert votre code ici
        int q=n/b;
        int r=n%b;
        s.push(r);
        while(q!=0){
            n=q;
            q=n/b;
            r=n%b;
            s.push(r);
        }
        int newrep=0;
        while(!s.isEmpty()){
            newrep=newrep*10+s.pop();
        }
        return newrep;
    }

    public static void main(String[] args) {
        
        if (args.length !=2) {
            System.out.print("Utilisation: java ConvertisseurBase <n:int> <base:int>");
            return;
          } 

        int n = Integer.parseInt(args[0]);
        int base = Integer.parseInt(args[1]); 

        ConvertisseurBase baseConverter = new ConvertisseurBase();
        System.out.println(n + " s'ecrit " + baseConverter.convert(n,base) + " en base " + base);
    }
}