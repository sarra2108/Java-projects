import java.util.EmptyStackException;

public class EmptyLinkedStackException extends EmptyStackException {


    private String msg;

    public void EmptyLinkedStackException() {
        msg = "La pile utilisant une liste chainée est vide";

    }
    public void setmsg(String value){
        msg=value;
    }
    public String getmsg(){
        return msg;
    }
}